namespace Model.Pacijenti
{
   public enum BracniStatus
   {
      neozenjen_neudata,
      ozenjen_udata,
      udovac_udovica,
      razveden_razvedena
   }
}