﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bolnica.Model.Prostorije
{
    public class BuducaZaliha:Zaliha
    {
        public DateTime Datum { get; set; }
    }
}
