namespace Model.Korisnici
{
   public class Specijalizacija
   {
      public int Id { get; set; }

      public string Naziv { get; set; }

      public string OblastMedicine { get; set; }
   
   }
}