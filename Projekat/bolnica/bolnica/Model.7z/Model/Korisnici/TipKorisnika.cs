namespace Model.Korisnici
{
    public enum TipKorisnika
    {
        upravnik,
        sekretar,
        lekar,
        pacijent
    }
}