namespace Model.Korisnici
{
    public class Sekretar : Zaposleni
    {
    }
}