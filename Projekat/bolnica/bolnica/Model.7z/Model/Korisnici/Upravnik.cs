namespace Model.Korisnici
{
    public class Upravnik : Zaposleni
    {
    }
}