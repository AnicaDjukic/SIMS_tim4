namespace Model.Pacijenti
{
    public enum Pol
    {
        muski,
        zenski
    }
}